#include<unistd.h>
#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/wait.h>
int main(int argc, char *argv[])
{
	pid_t ret; 
	int status;// to declare process id
	printf("welcome...pid=%d\n",getpid());
	printf("enter command : ");
	scanf("  %s ",argv);
	ret=fork();
	if(ret<0)
	{
		perror("fork");
		exit(1);
	}
	if(ret==0)
	{
		int k;
		execlp("command",argv[0]);
		printf("Child %d\n", getpid());
		if(k<0)
		{
			perror("execlp");
			exit(1);
		} 
		exit(0);
	}
	else		//ret value>0
	{	
		printf("status waiting...");
		 waitpid(ret, &status, 0);
		printf(" command executed\n");
	}
	return 0;
}
