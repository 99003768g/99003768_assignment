 #include <signal.h> 
#include <stdio.h> 
#include <stdlib.h> 
#include <sys/types.h> 
#include <unistd.h> 

// declaring the functions  
void sigquit(); 

// driver code 
void main() 
{ 
	int pid; 

	/* get child process */
	if ((pid = fork()) < 0) { 
		perror("fork"); 
		exit(1); 
	} 

	if (pid == 0) { /* child */  
		signal(SIGQUIT, sigquit); 
		for (;;) 
			; /* loop for ever */
	} 

	else /* parent */
	{ /* pid hold id of child */


		sleep(0.5); /* pause for 0.5 sec */
		printf("\nPARENT: sending SIGQUIT\n\n"); 
		kill(pid, SIGQUIT); 
		sleep(0.5); 
	} 
} 

void sigquit() 
{ 
	printf("child process is killed!\n"); 
	exit(0); 
} 