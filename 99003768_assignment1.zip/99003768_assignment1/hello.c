#include<stdio.h>
int main()
{
    printf("hello welcome to.......C");
    return 0;
}