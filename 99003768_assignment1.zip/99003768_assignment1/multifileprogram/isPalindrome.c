#include<stdio.h>
int isPalindrome(int number)
{
  int temp, r, rev=0;
  temp = number;

  while( number!=0 )
  {
     r = number % 10;
     rev = rev*10 + r;
     number =number/ 10;
  }

  if ( rev == temp ) return 0;
  else return 1;
}

int main()
{
    int number;
  printf("Enter the number: ");
  scanf("%d", &number);

  if(isPalindrome(number) == 0)
  {
  printf("%d is a palindrome number.\n",number);
  }
  else
  {
  printf("%d is not a palindrome number.\n",number);
  }

  return 0;
}