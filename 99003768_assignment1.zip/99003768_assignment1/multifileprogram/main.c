// C program to demonstrate creating processes using fork() 
#include <unistd.h> 
#include <stdio.h> 
#include<stdlib.h>

int main() 
{ 
	// Creating first child 
	int n1 = fork(); 
    int n2 = fork();

	// Creating second child. First child 
	// also executes this line and creates 
	// grandchild. 

	if (n1==0)
     { 
		printf("child 1 is created\n"); 
		printf("%d\n", n1); 
		printf(" child 1  id is %d \n", getpid()); 
       execlp("gcc", "gcc", "factorial.c", (char*)NULL);
    // printf("is it opening??????");
    //execlp("ls","-liha",NULL);
        printf("not working\n");
        exit(127); /* only if execv fails */
	}
    	if (n1==0)
     { 
		printf("child 2 is created\n"); 
		printf("%d\n", n2); 
		printf(" child 2  id is %d \n", getpid()); 
       execlp("gcc", "gcc", "isPalindrome.c", (char*)NULL);
    // printf("is it opening?????");
    //execlp("ls","-liha",NULL);
        printf("not working\n");
        exit(127); /* only if execv fails */
     }
	else
    { 
		printf("parent is created\n"); 
		//printf("%d %d \n", n1, n2); 
		printf(" parent id is %d \n", getpid()); 
	} 
	return 0; 
} 
