#include<unistd.h>
#include <stdio.h>
#include<fcntl.h>
int main()
{
FILE *fp;
fp  = fopen("data.txt", "w+");
fprintf(fp, "This is fprintf\n");
fputs("This is fputs\n", fp);
fclose(fp);
return 0;
}