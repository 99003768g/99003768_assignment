#include<unistd.h>
#include <stdio.h>
#include<fcntl.h>
#include<stdlib.h>
void main() 
{ 
    FILE *fptr; 
    char ch; 
    int word=0,character=0;
    //char copiedfile[20];
    printf("\n\n Count the number of words and characters in a file :\n");

    fptr=fopen("data.txt","r"); 
    if(fptr==NULL) 
     { 
         printf(" File does not exist or can not be opened."); 
      } 
    else 
        { 
          ch=fgetc(fptr); 
          //printf(" The content of the file %s are : ",copiedfile); 
          while(ch!=EOF) 
            { 
                printf("%c",ch);
                if(ch==' '||ch=='\n')
                    { 
                        word++; 
                    }
                    else
                    {
                        character++; 
                    }
                ch=fgetc(fptr); 
            }
        printf("\n The number of words in the  file name ||||||are : %d\n",word); 
        printf(" The number of characters in the  file are : %d\n\n",character);         
        } 
    fclose(fptr); 
}