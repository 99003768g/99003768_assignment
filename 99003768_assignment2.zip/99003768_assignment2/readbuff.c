#include <stdio.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>


int main() {
   int fd;
   int end_process;
   int stringlength;
   int read_bytes;
   char readbuf[80];
   char end_str[5];
   printf(" Send messages, infinitely, to end enter \"end\"\n");
   fd = open(FIFO_FILE, O_CREAT|O_RDWR);
   strcpy(end_str, "end");
   
   for (;;)
    {
      printf("Enter string: ");
      fgets(readbuf, sizeof(readbuf), stdin);
      stringlength = strlen(readbuf);
      readbuf[stringlength - 1] = '\0';
      end_process = strcmp(readbuf, end_str);
      
      //printf("end_process is %d\n", end_process);
      if (end_process != 0) 
      {
         write(fd, readbuf, strlen(readbuf));
         read_bytes = read(fd, readbuf, sizeof(readbuf));
         readbuf[read_bytes] = '\0';
         printf(" Received string: \"%s\" and length is %d\n", readbuf, (int)strlen(readbuf));
      } else
       {
         write(fd, readbuf, strlen(readbuf));
         close(fd);
         break;
      }
   }
   return 0;
}