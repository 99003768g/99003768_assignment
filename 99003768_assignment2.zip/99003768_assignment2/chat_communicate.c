// C Program for Message Queue (Writer Process) 
#include <stdio.h> 
#include <sys/ipc.h> 
#include <sys/msg.h> 
#define MAX 10 

// structure for message queue 
struct message_buffer { 
	long message_type; 
	char message_text[100]; 
} message; 

int main() 
{ 
	key_t key; 
	int messageid; 

	// ftok to generate unique key 
	key = ftok("chatfile", 65); 

	// messageget creates a message queue 
	// and returns identifier 
	messageid = messageget(key, 0666 | IPC_CREAT); 
	message.message_type = 1; 

	printf("Write Data : "); 
	fgets(message.message_text,MAX,stdin); 

	// messagesnd to send message 
	messagesnd(messageid, &message, sizeof(message), 0); 

	// display the message 
	printf("Data send is : %s \n", message.message_text); 

	return 0; 
} 